const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/sales', (req, res) => {
  const sql = 'SELECT month, amount FROM sales';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('❌ Failed to fetch data:', err.message);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});